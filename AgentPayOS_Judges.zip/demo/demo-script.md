
## Judge Demo Script (3–4 Minutes)

1. What problem we solve: AI agents + money gap
2. Connect MetaMask (live)
3. Show MNEE balance
4. Trigger autonomous agent payment
5. Show Etherscan transaction
6. Explain limits & escrow
7. Vision: autonomous AI economies
