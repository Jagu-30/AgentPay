
import React from "react";
import { WagmiConfig, createConfig, useAccount } from "wagmi";
import { mainnet } from "wagmi/chains";
import { MetaMaskConnector } from "wagmi/connectors/metaMask";

const config = createConfig({
  autoConnect: true,
  connectors: [new MetaMaskConnector({ chains: [mainnet] })],
  publicClient: undefined,
});

function Dashboard() {
  const { address, isConnected } = useAccount();
  return (
    <div>
      <h2>Status</h2>
      <p>Agent: Active</p>
      <p>Wallet: {isConnected ? address : "Not connected"}</p>
      <p>MNEE Balance: (live read placeholder)</p>
      <p>Last Tx: <a href="#" target="_blank">View on Etherscan</a></p>
    </div>
  );
}

export default function App() {
  return (
    <WagmiConfig config={config}>
      <div style={{ padding: 40 }}>
        <h1>AgentPay OS – Judge Demo</h1>
        <Dashboard />
      </div>
    </WagmiConfig>
  );
}
