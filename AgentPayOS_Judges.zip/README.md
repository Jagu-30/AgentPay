
# AgentPay OS – Judge Polished Edition 🏆

AgentPay OS is a programmable money infrastructure enabling autonomous AI agents
to transact using the MNEE USD-backed stablecoin on Ethereum.

## Why This Matters
AI agents can reason — but without money, they cannot act economically.
AgentPay OS bridges AI decision-making with real on-chain value transfer.

## Key Highlights for Judges
- Live MetaMask wallet connection
- Real MNEE on-chain transactions
- Agent-controlled treasury with limits
- Escrow-based settlement
- Clean dashboard + transaction visibility

## Demo Checklist
✔ Connect wallet  
✔ Show MNEE balance  
✔ Trigger agent payment  
✔ Show Etherscan link  

## Run Locally
```bash
cd backend && npm install && node server.js
cd frontend && npm install && npm start
```
